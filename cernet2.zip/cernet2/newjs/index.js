var i = 0;
var timer;
$(function ()
{
    timer=setInterval
    (
        function () {
            if (i == 4)
            { i = 0; }
            $(".img").eq(i).fadeIn(100).siblings().fadeOut(100);
            $(".tab").eq(i).addClass("bg").siblings().removeClass("bg");
            i++;
        }, 2000);
    $(".tab").hover(function ()
    {
        i = $(this).index(); Show();
        clearInterval(timer);
    }, function () {
        ShowTime();
    });
    $(".btn1").click(function () {
        clearInterval(timer);
        if (i == 0)
        { i = 4 };
        i--;
        Show();
        ShowTime();
    });
    $(".btn2").click(function () {
        clearInterval(timer);
        if (i == 3)
        { i = -1};
        i++;
        Show();
        ShowTime();
    });

});
function Show()
{
    $(".img").eq(i).fadeIn(100).siblings().fadeOut(100);
    $(".tab").eq(i).addClass("bg").siblings().removeClass("bg");
}
function ShowTime()
{
    timer = setInterval
    (
        function () {
            if (i == 3)
            { i = 0; }
            i++;
            $(".img").eq(i).fadeIn(100).siblings().fadeOut(100);
            $(".tab").eq(i).addClass("bg").siblings().removeClass("bg");
        }, 2000);
}