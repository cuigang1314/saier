package action;
/**
 * execute()方法的返回值有的为空
 * 统一处理系统连接数据库
 * @Author yh_my
 */

import com.opensymphony.xwork2.Action;
import mysql.SelectData;
import org.apache.struts2.ServletActionContext;

import javax.servlet.http.*;

import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class SelectUser implements Action{

    private String selectuserform = null;

    public String getSelectuserform() {
        return selectuserform;
    }

    public void setSelectuserform(String selectuserform) {
        this.selectuserform = selectuserform;
    }

    @Override
    public String execute() throws Exception {

        ResultSet resultSet = null;
        SelectData selectData = new SelectData();
        String password = null;
        try{
            resultSet = selectData.Select("SELECT password FROM StudentTable WHERE " +
                    "StudentNumber = \'" + selectuserform + "\';");
            HttpServletResponse response = ServletActionContext.getResponse();
            response.setContentType("text/html;charset=utf-8");
            if(resultSet.next() == true && resultSet.getString("password").equals("") == false){
                password = resultSet.getString("password");
                response.addHeader("Number",selectuserform);
                response.addHeader("Password",password);
                //执行成功
                return "1";
            }
            resultSet = null;
            resultSet = selectData.Select("SELECT password FROM TeacherTable WHERE " +
                    "TeacherNumber = \'" + selectuserform + "\';");

            if(resultSet.next() == true && resultSet.getString("password").equals("") == false){
                password = resultSet.getString("password");
                response.addHeader("Number",selectuserform);
                response.addHeader("Password",password);
                //执行成功
                return "1";
            }
        }catch (Exception e){
            System.out.println("SQL查询语句执行失败" + e);
            e.printStackTrace(System.out);
            HttpServletResponse response = ServletActionContext.getResponse();
            response.setContentType("text/html;charset=utf-8");
            PrintWriter out = response.getWriter();
            out.print("<script>alert('服务器故障');window.location.href='adminuser.html';</script>");
            return null;
        }
        return null;
    }
}
