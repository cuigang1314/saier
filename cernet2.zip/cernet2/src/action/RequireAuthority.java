package action;

import com.opensymphony.xwork2.Action;
import org.apache.struts2.ServletActionContext;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;

import mysql.SelectData;

import java.sql.ResultSet;

public class RequireAuthority implements Action {
    @Override
    public String execute() throws Exception {
        String mark = null;
        String userName = null;
        String rank = null;
        Cookie cookies[] = ServletActionContext.getRequest().getCookies();
        for(Cookie cookie : cookies){
            if(cookie.getName().equals("UserId") == true){
                userName = cookie.getValue();
            }else if(cookie.getName().equals("UserRank") == true){
                rank = cookie.getValue();
            }
        }
        if(userName != null && rank.equals("1")){
            String sql = "Select approve from studenttable where studentnumber = '" + userName + "'";
            SelectData selectData = new SelectData();
            ResultSet resultSet = selectData.Select(sql);
            while(resultSet.next()){
                if(resultSet.getString("approve").equals("1")){
                    mark = "1";
                    HttpServletRequest request = ServletActionContext.getRequest();
                    request.setAttribute("mark",mark);
                    return "success";
                }
            }
            if(resultSet != null)
                resultSet.close();
            sql = "Select refuse from studenttable where studentnumber = '" + userName + "'";
            resultSet = selectData.Select(sql);
            while(resultSet.next()){
                if(resultSet.getString("refuse").equals("1")){
                    mark = "2";
                    HttpServletRequest request = ServletActionContext.getRequest();
                    request.setAttribute("mark",mark);
                    return "success";
                }
            }
            if(resultSet != null) resultSet.close();
            sql = "Select request from studenttable where studentnumber = '" + userName + "'";
            resultSet = selectData.Select(sql);
            while(resultSet.next()){
                if(resultSet.getString("request").equals("1")){
                    mark = "3";
                    HttpServletRequest request = ServletActionContext.getRequest();
                    request.setAttribute("mark",mark);
                    return "success";
                }
            }
            mark = "4";
            HttpServletRequest request = ServletActionContext.getRequest();
            request.setAttribute("mark",mark);
            return "success";
        }else if(rank.equals("2")){
            String sql = "Select approve from teachertable where teachernumber  = '" + userName + "'";
            SelectData selectData = new SelectData();
            ResultSet resultSet = selectData.Select(sql);
            while(resultSet.next()){
                if(resultSet.getString("approve").equals("1")){
                    mark = "1";
                    HttpServletRequest request = ServletActionContext.getRequest();
                    request.setAttribute("mark",mark);
                    return "success";
                }
            }
            if(resultSet != null)
                resultSet.close();
            sql = "Select refuse from teachertable where teachernumber = '" + userName + "'";
            resultSet = selectData.Select(sql);
            while(resultSet.next()){
                if(resultSet.getString("refuse").equals("1")){
                    mark = "2";
                    HttpServletRequest request = ServletActionContext.getRequest();
                    request.setAttribute("mark",mark);
                    return "success";
                }
            }
            if(resultSet != null) resultSet.close();
            sql = "Select request from teachertable where teachernumber = '" + userName + "'";
            resultSet = selectData.Select(sql);
            while(resultSet.next()){
                if(resultSet.getString("request").equals("1")){
                    mark = "3";
                    HttpServletRequest request = ServletActionContext.getRequest();
                    request.setAttribute("mark",mark);
                    return "success";
                }
            }
            mark = "4";
            HttpServletRequest request = ServletActionContext.getRequest();
            request.setAttribute("mark",mark);
            return "success";
        }else{
            return "failed";
        }
    }
}
