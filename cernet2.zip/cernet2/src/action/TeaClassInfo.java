package action;

import com.opensymphony.xwork2.Action;
import mysql.SelectData;
import org.apache.struts2.ServletActionContext;

import javax.servlet.http.HttpServletResponse;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class TeaClassInfo implements Action {
    private String userId = null;
    private List<String> lists = new ArrayList<String>();

    public List<String> getLists() {
        return lists;
    }

    public void setLists(List<String> lists) {
        this.lists = lists;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    @Override
    public String execute() throws Exception {
        ResultSet resultSet = null;
        SelectData selectData = new SelectData();
        try{
            resultSet = selectData.Select("Select CourseName, CourseDescription, x.CourseId " +
                    "FROM VideoTable x, CourseTable y " +
                    "Where x.CourseId = y.CourseId and x.TeacherNumber = \'" + userId + "\'");
        }catch (Exception e){
            System.out.println("查询失败" + e);
            HttpServletResponse response = ServletActionContext.getResponse();
            response.setContentType("text/html;charset=utf-8");
            PrintWriter out = response.getWriter();
            out.print("<script>alert('连接服务器失败');window.location.href='teaindex.html';</script>");
            return null;
        }

        int count = 0;
        boolean work = false;
        boolean empty = true;
        while(resultSet.next()){
            empty = false;
            if(work == true){
                lists.set(count * 3,resultSet.getString("CourseName"));
                lists.set(count * 3 + 1, resultSet.getString("CourseDescription"));
                lists.set(count * 3 + 2, resultSet.getString("CourseId"));
            }else if(work == false){
                lists.add(resultSet.getString("CourseName"));
                lists.add(resultSet.getString("CourseDescription"));
                lists.add(resultSet.getString("CourseId"));
            }
            count ++;
            count %= 6;
            if(count == 0)
                work = true;
        }
        if(work == false && empty == false){
            for(int i = count; i < 6; i++){
                lists.add(lists.get((i%count)*3));
                lists.add(lists.get((i%count)*3 + 1));
                lists.add(lists.get((i%count)*3 + 2));
            }
        }
        if(empty == false)
            return SUCCESS;
        else {
            HttpServletResponse response = ServletActionContext.getResponse();
            response.setContentType("text/html;charset=utf-8");
            PrintWriter out = response.getWriter();
            out.print("<script>alert('您尚未上传课程'); window.location.href = 'teaindex.html';</script>");
            return null;
        }
    }
}
