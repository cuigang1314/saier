package action;

import com.opensymphony.xwork2.Action;
import mysql.SelectData;
import mysql.UpdateData;
import org.apache.commons.io.FileUtils;
import org.apache.struts2.ServletActionContext;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.File;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.List;

public class UploadFile implements Action{

    private String classname = null;
    private String courseintro = null;
    private String pdftitle = null;
    //文件内容
    private List<File> uploadfile = null;

    //文件后缀
    private List <String> uploadfileContentType = null;

    //文件名字
    private List<String> uploadfileFileName = null;

    public String getClassname() {
        return classname;
    }

    public void setClassname(String classname) {
        this.classname = classname;
    }

    public List<File> getUploadfile() {
        return uploadfile;
    }

    public void setUploadfile(List<File> uploadfile) {
        this.uploadfile = uploadfile;
    }

    public List<String> getUploadfileContentType() {
        return uploadfileContentType;
    }

    public void setUploadfileContentType(List<String> uploadfileContentType) {
        this.uploadfileContentType = uploadfileContentType;
    }

    public List<String> getUploadfileFileName() {
        return uploadfileFileName;
    }

    public void setUploadfileFileName(List<String> uploadfileFileName) {
        this.uploadfileFileName = uploadfileFileName;
    }

    public String getCourseintro() {
        return courseintro;
    }

    public void setCourseintro(String courseintro) {
        this.courseintro = courseintro;
    }

    public String getPdftitle() {
        return pdftitle;
    }

    public void setPdftitle(String pdftitle) {
        this.pdftitle = pdftitle;
    }
    @Override
    public String execute() throws Exception {

        int courseid = 0;
        ResultSet resultSet = null;
        SelectData selectData = new SelectData();
        try{
            int end = 0;
            resultSet = selectData.Select("SELECT courseid FROM coursetable");
            try{
                if(resultSet.last() == true){
                    try{
                        end = Integer.parseInt(resultSet.getString("courseid"));
                    }catch (Exception e){
                        end = 0;
                    }
                }else{
                    end = 1;
                }
            }catch (Exception e){
                e.printStackTrace();
                end = 0;
            }
            courseid = end + 1;
        }catch (Exception e){
            System.out.println("Sql 语句查询失败" + e);
            HttpServletResponse response = ServletActionContext.getResponse();
            response.setContentType("text/html;charset=utf-8");
            PrintWriter out = response.getWriter();
            out.print("<script>alert('连接服务器失败');window.location.href='teaaddclass.html';</script>");
            return null;
        }
        String newFileName = null;
        String realpath = ServletActionContext.getServletContext()
                .getRealPath("/");
        String path = realpath + "course/" + courseid;
        String relativePath = "course/" + courseid;
        File savedFile  = null;
        String videoname = null;
        if(uploadfile.get(0) != null){
            videoname = uploadfileFileName.get(0);
            newFileName = courseid + "." + videoname.substring(videoname.lastIndexOf('.') + 1);
            savedFile = new File(new File(path),newFileName);
            if(!savedFile.getParentFile().exists())
                savedFile.getParentFile().mkdirs();

            try{
                FileUtils.copyFile(uploadfile.get(0),savedFile);
            }catch (Exception e){
                System.out.println("上传视频文件失败" + e);
                savedFile.getParentFile().delete();
                HttpServletResponse response = ServletActionContext.getResponse();
                response.setContentType("text/html;charset=utf-8");
                PrintWriter out = response.getWriter();
                out.print("<script>alert('服务器故障');window.location.href='teaaddclass.html';</script>");
                return null;
            }
        }
        String pptname;
        if(uploadfile.get(1) != null){

            pptname = uploadfileFileName.get(1);
            newFileName = courseid + "." + pptname.substring(pptname.lastIndexOf('.') + 1);

            savedFile = new File(new File(path),newFileName);

            if(!savedFile.getParentFile().exists())
                savedFile.getParentFile().mkdirs();

            try{
                FileUtils.copyFile(uploadfile.get(1),savedFile);
            }catch (Exception e){
                System.out.println("上传ppt文件文件失败" + e);
                savedFile.getParentFile().delete();
                HttpServletResponse response = ServletActionContext.getResponse();
                response.setContentType("text/html;charset=utf-8");
                PrintWriter out = response.getWriter();
                out.print("<script>alert('服务器故障');window.location.href='teaaddclass.html';</script>");
                return null;
            }
        }

        String teacherName = null;
        //数据库操作
        UpdateData updateData = new UpdateData();
        try{
            HttpServletRequest request = ServletActionContext.getRequest();
            Cookie [] cookies = request.getCookies();

            for(int i = 0; i < cookies.length; i++){
                if(cookies[i].getName().equals("UserId")){
                    teacherName = cookies[i].getValue();
                    break;
                }
            }
            updateData.Update("INSERT INTO CourseTable VALUES (\'" + courseid +"\',\'" +
                    classname + "\',\'"  + courseintro +"\')");

            updateData.Update("INSERT INTO PdfTable VALUES (\'" + courseid +"\',\'" +
                    pdftitle + "\',\'" + courseid + "\',\'"  + relativePath +"\')");

            videoname = videoname.split("\\s+")[0];
            updateData.Update("INSERT INTO VideoTable VALUES (\'" + courseid +"\',\'" +
                    videoname + "\',\'" + courseid + "\',\'"  + relativePath + "\',\'" + teacherName +"\')");

        }catch (Exception e){

            System.out.println("数据插入数据库失败" + e);
            HttpServletResponse response = ServletActionContext.getResponse();
            response.setContentType("text/html;charset=utf-8");
            PrintWriter out = response.getWriter();
            out.print("<script>alert('服务器故障');window.location.href='teaaddclass.html';</script>");
            return null;
        }

        return "1";

    }
}
