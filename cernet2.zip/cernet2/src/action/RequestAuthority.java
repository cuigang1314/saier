package action;

import com.opensymphony.xwork2.Action;
import mysql.SelectData;
import mysql.UpdateData;
import org.apache.struts2.ServletActionContext;
import javax.servlet.ServletResponse;
import javax.servlet.http.Cookie;
import java.io.PrintWriter;
import java.sql.ResultSet;

public class RequestAuthority implements Action {

    @Override
    public String execute() throws Exception {
        String userName = null;
        String rank = null;
        Cookie cookies[] = ServletActionContext.getRequest().getCookies();
        for(Cookie cookie : cookies){
            if(cookie.getName().equals("UserId") == true){
                userName = cookie.getValue();
            }else if(cookie.getName().equals("UserRank") == true){
                rank = cookie.getValue();
            }
        }
        UpdateData updateData = new UpdateData();
        SelectData selectData = new SelectData();
        if(userName != null && rank.equals("1")){
            String sql = "Select approve from studenttable where studentnumber = '" + userName + "'";
            ResultSet resultSet = selectData.Select(sql);
            while(resultSet.next()){
                if(resultSet.getString("approve").equals("1")){
                    ServletResponse response = ServletActionContext.getResponse();
                    response.setContentType("text/html;charset=utf-8");
                    PrintWriter out = response.getWriter();
                    out.println("<script type='text/javascript'>");
                    out.println("alert('您已经获取权限');window.location.href='stuindex.html';");
                    out.println("</script>");
                    return null;
                }
            }
            sql = "Update studenttable set approve = '0', request = '1', refuse = '0' where " +
                    "studentnumber = '" + userName + "'";
            updateData.Update(sql);
            ServletResponse response = ServletActionContext.getResponse();
            response.setContentType("text/html;charset=utf-8");
            PrintWriter out = response.getWriter();
            out.println("<script type='text/javascript'>");
            out.println("alert('您的请求已经提交');window.location.href='stuindex.html';");
            out.println("</script>");
            return null;
        }else if(userName != null && rank.equals("2")){
            String sql = "Select approve from teachertable where teachernumber = '" + userName + "'";
            ResultSet resultSet = selectData.Select(sql);
            while(resultSet.next()){
                if(resultSet.getString("approve").equals("1")){
                    ServletResponse response = ServletActionContext.getResponse();
                    response.setContentType("text/html;charset=utf-8");
                    PrintWriter out = response.getWriter();
                    out.println("<script type='text/javascript'>");
                    out.println("alert('您已经获取权限');window.location.href='teaindex.html';");
                    out.println("</script>");
                    return null;
                }
            }
            sql = "Update studenttable set approve = '0', request = '1', refuse = '0' where " +
                    "studentnumber = '" + userName + "'";
            updateData.Update(sql);
            ServletResponse response = ServletActionContext.getResponse();
            response.setContentType("text/html;charset=utf-8");
            PrintWriter out = response.getWriter();
            out.println("<script type='text/javascript'>");
            out.println("alert('您的请求已经提交');window.location.href='teaindex.html';");
            out.println("</script>");
            return null;
        }else{
            ServletResponse response = ServletActionContext.getResponse();
            response.setContentType("text/html;charset=utf-8");
            PrintWriter out = response.getWriter();
            out.println("<script type='text/javascript'>");
            out.println("alert('发生错误');");
            out.println("</script>");
        }
        return null;
    }
}
