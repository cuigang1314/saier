package action;

import com.opensymphony.xwork2.Action;
import mysql.UpdateData;
import org.apache.struts2.ServletActionContext;

import javax.servlet.ServletResponse;
import java.io.PrintWriter;

public class Approve implements Action{

    String Number = null;
    String Type = null;

    public String getNumber() {
        return Number;
    }

    public void setNumber(String number) {
        Number = number;
    }

    public String getType() {
        return Type;
    }

    public void setType(String type) {
        Type = type;
    }

    @Override
    public String execute() throws Exception {

        UpdateData updateData = new UpdateData();
        String sql = null;
        if(Type.equals("1") == true){
            sql = "Update studenttable Set approve = '1' , refuse = '0', request = '0' where " +
                    "studentnumber = '" + Number + "'";
        }else if(Type.equals("2") == true){
            sql = "Update teachertable Set approve = '1' , refuse = '0', request = '0' where " +
                    "teachernumber = '" + Number + "'";
        }else{
            return "failed";
        }
        try{
            updateData.Update(sql);
        }catch (Exception e){
            e.printStackTrace();
            return "failed";
        }

        ServletResponse response = ServletActionContext.getResponse();
        response.setContentType("text/html;charset=utf-8");
        PrintWriter out = response.getWriter();
        out.write("<script type='text/javascript'>");
        out.write("alert('成功审批');window.location.href='adminReview.do';");
        out.write("</script>");
        out.close();
        return null;
    }
}
