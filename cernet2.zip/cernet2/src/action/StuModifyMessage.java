package action;

import com.opensymphony.xwork2.Action;
import mysql.UpdateData;
import org.apache.struts2.ServletActionContext;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

public class StuModifyMessage implements Action{


    private String stuname = null;
    private String stucollege = null;
    private String stuprofession = null;
    private String stumail = null;

    public String getStuname() {
        return stuname;
    }

    public void setStuname(String stuname) {
        this.stuname = stuname;
    }

    public String getStucollege() {
        return stucollege;
    }

    public void setStucollege(String stucollege) {
        this.stucollege = stucollege;
    }

    public String getStuprofession() {
        return stuprofession;
    }

    public void setStuprofession(String stuprofession) {
        this.stuprofession = stuprofession;
    }

    public String getStumail() {
        return stumail;
    }

    public void setStumail(String stumail) {
        this.stumail = stumail;
    }

    @Override
    public String execute() throws Exception {

        HttpServletRequest request = ServletActionContext.getRequest();
        Cookie[]cookies = null;
        cookies = request.getCookies();
        String stuNumber = null;

        for(int i = 0; i < cookies.length; i++){
            if(cookies[i].getName().equals("UserId") == true){
                stuNumber = cookies[i].getValue();
                break;
            }
        }

        UpdateData updateData = new UpdateData();
        try{
            updateData.Update("Update StudentTable " +
                    "SET studentName=\'" + stuname + "\', " +
                    "college=\'" + stucollege + "\', " +
                    "profession=\'" + stuprofession + "\', " +
                    "mail=\'" + stumail + "\'" +
                    "WHERE StudentNumber=\'" + stuNumber + "\';"
            );

            try{

                HttpServletResponse response = ServletActionContext.getResponse();
                response.setContentType("text/html;charset=utf-8");
                PrintWriter out = response.getWriter();
                out.print("<script>alert('数据成功插入');location.href='stuindex.html'</script>");
                return null;
            }catch (Exception e){
                System.out.println("alert语句执行错误 " + e);
                HttpServletResponse response = ServletActionContext.getResponse();
                response.setContentType("text/html;charset=utf-8");
                PrintWriter out = response.getWriter();
                out.print("<script>alert('连接服务器失败');window.location.href='stuindex.html';</script>");
                return null;
            }

        }catch (Exception e){

            HttpServletResponse response = ServletActionContext.getResponse();
            response.setContentType("text/html;charset=utf-8");
            PrintWriter out = response.getWriter();
            out.print("<script>alert('服务器故障');location.href='stuindex.html'</script>");
            System.out.println("插入语句查询失败 " + e);
            return null;
        }
    }
}
