package mysql;

import java.sql.*;

public class UpdateData {
    private String url = null;
    private String name = null;
    private String pwd = null;
    public UpdateData(){
        url = "jdbc:mysql://localhost:3306/videoclassroom?useSSL=false&useUnicode=true&characterEncoding=UTF8";
        name = "root";
        pwd = "000000";
    }
    public boolean Update(String sql) throws ClassNotFoundException, SQLException {

        try{
            Class.forName("com.mysql.jdbc.Driver").newInstance();
        }catch (ClassNotFoundException e){
            throw e;
        }catch (IllegalAccessException e){
            System.out.println("Illegal Access On Select");
        }catch (Exception e){
            System.out.println(e);
        }
        try{

            Connection connection = null;
            Statement statement = null;
            connection = DriverManager.getConnection(url,name,pwd);
            statement = connection.createStatement();
            statement.executeUpdate(sql);
            return true;
        }catch (SQLException e){
            throw e;
        }

    }
}
