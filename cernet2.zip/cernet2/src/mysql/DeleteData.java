package mysql;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class DeleteData {
    private String url = null;
    private String name = null;
    private String pwd = null;

    public DeleteData() {
        url = "jdbc:mysql://localhost:3306/videoclassroom?useSSL=false&useUnicode=true&characterEncoding=UTF8";
        name = "root";
        pwd = "000000";
    }

    public int Delete(String sql) throws ClassNotFoundException, SQLException {

        try {
            Class.forName("com.mysql.jdbc.Driver").newInstance();
        } catch (ClassNotFoundException e) {
            throw e;
        } catch (IllegalAccessException e) {
            System.out.println("Illegal Access On Select");
        } catch (Exception e) {
            System.out.println(e);
        }
        try {
            Connection connection = null;
            Statement statement = null;
            connection = DriverManager.getConnection(url, name, pwd);
            statement = connection.createStatement();
            int work = statement.executeUpdate(sql);
            return work;
        } catch (SQLException e) {
            throw e;
        }
    }
}