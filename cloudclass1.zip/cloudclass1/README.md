# 慕课网

   仿慕课网的app，主要实现了首次安装的引导，封装了网络请求（synHttp）,图片缓存框架（univer-image-loder）,数据库orm，
   以及一些其他的常用的jar
   
 
  
  主要分为四大板块：
  【课程】
  【社区】
  【下载】
  【我的】
  
   ![ABC](https://github.com/xiangzhihong/ImoocPro/blob/master/shotscreen/device-2016-02-24-174607.png) 
   ![ABC](https://github.com/xiangzhihong/ImoocPro/blob/master/shotscreen/device-2016-02-24-174629.png) 
   ![ABC](https://github.com/xiangzhihong/ImoocPro/blob/master/shotscreen/device-2016-02-24-174654.png) 
   
   
  整体架构采用了MVC的设计模式
  项目中由于存在大量网络图片，所以采用了二级缓存
  
 
  
  
