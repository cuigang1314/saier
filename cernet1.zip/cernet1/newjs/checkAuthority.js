function checkAuthority(authority) {
    var cookies = document.cookie;
    var cookie_pos = cookies.indexOf("UserRank");
    console.log(authority);
    if(cookie_pos == -1){
        alert("你尚未登录");
        window.location.href = 'login.html';
    }else if(authority != 0){
        console.log("2");
        cookie_pos += "UserRank".length + 1;
        var end = cookies.indexOf(";",cookie_pos);
        if(end == -1){
            end = cookies.length;
        }
        var value = unescape(cookies.substring(cookie_pos,end));
        if(value.toString() != authority.toString()){
            alert("请重新登录");
            window.location.href = 'login.html';
        }
        console.log("1222");
    }
}
