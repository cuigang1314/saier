﻿function Login()
{
    var number = document.getElementById("username");
    var pwd = document.getElementById("password");
    if(number==""||pwd=="")
    {
        layer.alert("用户名或密码不能为空！",{title:"提示",icon:5});
    }
}