package interceptors;

import action.Login;
import com.opensymphony.xwork2.Action;
import com.opensymphony.xwork2.ActionInvocation;
import com.opensymphony.xwork2.interceptor.Interceptor;
import org.apache.struts2.ServletActionContext;
import javax.servlet.http.Cookie;

public class LoginInterceptor implements Interceptor {
    @Override
    public void destroy() {

    }

    @Override
    public void init() {

    }

    @Override
    public String intercept(ActionInvocation actionInvocation) throws Exception {

        Object action = actionInvocation.getAction();
        if(action instanceof Login){
            return actionInvocation.invoke();
        }

        Cookie cookies[] = ServletActionContext.getRequest().getCookies();
        for(Cookie cookie : cookies) {
            if (cookie.getName().equals("UserId") == true) {
                return actionInvocation.invoke();
            }
        }
        return "login";
    }
}
