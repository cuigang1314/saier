package action;

import com.opensymphony.xwork2.Action;
import mysql.UpdateData;
import org.apache.struts2.ServletActionContext;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

public class ModifyMessage implements Action {

    private String teaname = null;
    private String teacollege = null;
    private String teaprofession = null;
    private String teamail = null;

    public String getTeaname() {
        return teaname;
    }

    public void setTeaname(String teaname) {
        this.teaname = teaname;
    }

    public String getTeacollege() {
        return teacollege;
    }

    public void setTeacollege(String teacollege) {
        this.teacollege = teacollege;
    }

    public String getTeaprofession() {
        return teaprofession;
    }

    public void setTeaprofession(String teaprofession) {
        this.teaprofession = teaprofession;
    }

    public String getTeamail() {
        return teamail;
    }

    public void setTeamail(String teamail) {
        this.teamail = teamail;
    }

    @Override
    public String execute() throws Exception {

        HttpServletRequest request = ServletActionContext.getRequest();
        Cookie []cookies = null;
        cookies = request.getCookies();
        String teaNumber = null;
        for(int i = 0; i < cookies.length; i++){
            if(cookies[i].getName().equals("UserId") == true){
                teaNumber = cookies[i].getValue();
                break;
            }
        }
        UpdateData updateData = new UpdateData();
        try{
            updateData.Update("Update TeacherTable " +
                    "SET teacherName=\'" + teaname + "\', " +
                    "college=\'" + teacollege + "\', " +
                    "profession=\'" + teaprofession + "\', " +
                    "mail=\'" + teamail + "\'" +
                    "WHERE TeacherNumber=\'" + teaNumber + "\';"
            );

            try{

                HttpServletResponse response = ServletActionContext.getResponse();
                response.setContentType("text/html;charset=utf-8");
                PrintWriter out = response.getWriter();
                out.print("<script>alert('数据成功插入');location.href='teaindex.html'</script>");
                return null;
            }catch (Exception e){
                System.out.println("alert语句执行错误 " + e);
                HttpServletResponse response = ServletActionContext.getResponse();
                response.setContentType("text/html;charset=utf-8");
                PrintWriter out = response.getWriter();
                out.print("<script>alert('连接服务器失败');window.location.href='teaindex.html';</script>");
                return null;
            }

        }catch (Exception e){

            HttpServletResponse response = ServletActionContext.getResponse();
            response.setContentType("text/html;charset=utf-8");
            PrintWriter out = response.getWriter();
            out.print("<script>alert('服务器故障');location.href='teaindex.html'</script>");
            System.out.println("插入语句查询失败 " + e);
            return null;
        }
    }
}
