package action;


import com.opensymphony.xwork2.Action;
import mysql.UpdateData;
import org.apache.struts2.ServletActionContext;

import javax.servlet.http.HttpServletResponse;
import java.io.File;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class TeaDeleteClass implements Action {
    private String userId = null;
    private String classId = null;

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getClassId() {
        return classId;
    }

    public void setClassId(String classId) {
        this.classId = classId;
    }

    @Override
    public String execute() throws Exception {

        UpdateData updateData = new UpdateData();
        try{
            updateData.Update("DELETE FROM CourseRecord WHERE CourseId =\'" +
                    classId + "\'");
            updateData.Update("DELETE FROM PdfTable WHERE CourseId =\'" +
                    classId + "\'");
            updateData.Update("DELETE FROM VideoTable WHERE CourseId =\'" +
                    classId + "\'");
            updateData.Update("DELETE FROM CourseTable WHERE CourseId =\'" +
                    classId + "\'");
        }catch (Exception e){
            System.out.println("删除失败" + e);
            HttpServletResponse response = ServletActionContext.getResponse();
            response.setContentType("text/html;charset=utf-8");
            PrintWriter out = response.getWriter();
            out.print("<script>alert('连接服务器失败');window.location.href='teacourse.html';</script>");
            return null;
        }
        String realpath = ServletActionContext.getServletContext()
                .getRealPath("/");
        String dir = realpath + "course/" + classId;
        System.out.println(dir);
        File file = new File(dir);
        if(file.isDirectory()){
            System.out.println("12");
            File[] files = file.listFiles();
            for (int i = 0;i < files.length;i ++) {
                files[i].delete();
            }
            file.delete();
        }
        HttpServletResponse response = ServletActionContext.getResponse();
        response.setContentType("text/html;charset=utf-8");
        PrintWriter out = response.getWriter();
        out.print("<script>alert('删除成功');window.location.href='teacourse.html';</script>");

        return null;
    }
}
