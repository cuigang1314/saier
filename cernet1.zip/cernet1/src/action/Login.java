package action;

import mysql.SelectData;
import com.opensymphony.xwork2.Action;
import org.apache.struts2.ServletActionContext;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletResponse;
import java.io.PrintWriter;
import java.sql.ResultSet;

public class Login implements Action {

    private String username = null;
    private String password = null;
    private String logradio = null;

    public String getLogradio() {
        return logradio;
    }

    public void setLogradio(String logradio) {
        this.logradio = logradio;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    @Override
    public String execute() throws Exception {

        ResultSet resultSet = null;
        SelectData selectData = new SelectData();
        try{
            resultSet = null;
            if(logradio.equals("one")){
                resultSet = selectData.Select("Select password from StudentTable Where " +
                        "StudentNumber = \'" + username + "\'");
            }else if(logradio.equals("two")){
                resultSet = selectData.Select("Select password from TeacherTable WHERE " +
                        "TeacherNumber = \'" + username + "\'");
            }else if(logradio.equals("three")){
                resultSet = selectData.Select("Select password from AdminTable WHERE " +
                        "AdminNumber = \'" + username + "\'");
            }

            if(resultSet == null){
                HttpServletResponse response = ServletActionContext.getResponse();
                response.setContentType("text/html;charset=utf-8");
                PrintWriter out = response.getWriter();
                out.print("<script>alert('您未注册');window.location.href='login.html';</script>");
                return null;
            }
            if(resultSet.next() == false){
                resultSet.close();
                HttpServletResponse response = ServletActionContext.getResponse();
                response.setContentType("text/html;charset=utf-8");
                PrintWriter out = response.getWriter();
                out.print("<script>alert('您未注册');window.location.href='login.html';</script>");
                return null;
            }

            Cookie userIdCookie = new Cookie("UserId",username);
            Cookie userRankcookie = null;
            if(logradio.equals("one") && resultSet != null && resultSet.getString("password").equals(this.password)) {

                //学生用户登录成功

                resultSet.close();
                HttpServletResponse response = ServletActionContext.getResponse();
                userRankcookie = new Cookie("UserRank","1");
                userIdCookie.setMaxAge(1000 * 60 * 10);
                userRankcookie.setMaxAge(1000 * 60 * 10);
                response.addCookie(userIdCookie);
                response.addCookie(userRankcookie);
                return "1";

            }
            if(logradio.equals("two") && resultSet != null && resultSet.getString("password").equals(this.password)) {

                //教师用户登陆成功

                resultSet.close();

                userRankcookie = new Cookie("UserRank","2");
                HttpServletResponse response = ServletActionContext.getResponse();
                userIdCookie.setMaxAge(1000 * 60 * 10);
                userRankcookie.setMaxAge(1000 * 60 * 10);
                response.addCookie(userIdCookie);
                response.addCookie(userRankcookie);
                return "2";
            }

            if(logradio.equals("three") && resultSet != null && resultSet.getString("password").equals(this.password)){

                //管理员登陆成功

                resultSet.close();

                userRankcookie = new Cookie("UserRank","3");
                HttpServletResponse response = ServletActionContext.getResponse();
                userIdCookie.setMaxAge(1000 * 60 * 10);
                userRankcookie.setMaxAge(1000 * 60 * 10);
                response.addCookie(userIdCookie);
                response.addCookie(userRankcookie);
                return "3";
            }

            //用户尚未注册
            HttpServletResponse response = ServletActionContext.getResponse();
            response.setContentType("text/html;charset=utf-8");
            PrintWriter out = response.getWriter();
            out.print("<script>alert('用户名或密码错误');window.location.href='login.html';</script>");
            return null;
        }catch (Exception e){
            System.out.println("查询语句执行失败" + e.toString());
        }
        if(resultSet != null){
            resultSet.close();
        }
        HttpServletResponse response = ServletActionContext.getResponse();
        response.setContentType("text/html;charset=utf-8");
        PrintWriter out = response.getWriter();
        out.print("<script>alert('服务器故障');window.location.href='login.html';</script>");
        return null;
    }
}
