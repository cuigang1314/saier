package action;

import mysql.DeleteData;
import com.opensymphony.xwork2.Action;
import org.apache.struts2.ServletActionContext;
import javax.servlet.http.HttpServletResponse;
import java.io.PrintWriter;

public class DeleteUser implements Action{

    private String selectuserform = null;

    public String getSelectuserform() {
        return selectuserform;
    }

    public void setSelectuserform(String selectuserform) {
        this.selectuserform = selectuserform;
    }

    @Override
    public String execute() throws Exception {

        DeleteData deleteData = new DeleteData();
        try{
            int work = deleteData.Delete("DELETE FROM StudentTable WHERE StudentNumber =" +
                    "\'" + selectuserform + "\';");
            if(work == 0){
                work = deleteData.Delete("DELETE FROM TeacherTable WHERE TeacherNumber =" +
                        "\'" + selectuserform + "\';");
                HttpServletResponse response = ServletActionContext.getResponse();
                response.setContentType("text/html;charset=utf-8");
                PrintWriter out = response.getWriter();
                if(work == 0){
                    out = response.getWriter();
                    out.print("<script>alert('用户删除失败');location.href='error.html'</script>");
                    return null;
                }else{
                    out = response.getWriter();
                    out.print("<script>alert('用户删除成功');location.href='adminuser.html'</script>");
                    return null;
                }
            }else{
                HttpServletResponse response = ServletActionContext.getResponse();
                response.setContentType("text/html;charset=utf-8");
                PrintWriter out = response.getWriter();
                out.print("<script>alert('用户删除成功');location.href='adminuser.html'</script>");
                return null;
            }
        }catch (Exception e){
            HttpServletResponse response = ServletActionContext.getResponse();
            response.setContentType("text/html;charset=utf-8");
            PrintWriter out = response.getWriter();
            System.out.println("SQL语句执行失败 " + e);
            out.print("<script>alert('连接服务器失败');window.location.href='adminuser.html';</script>");
            return null;
        }
    }
}
