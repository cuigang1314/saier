package action;

import mysql.UpdateData;
import com.opensymphony.xwork2.Action;
import org.apache.struts2.ServletActionContext;
import javax.servlet.http.HttpServletResponse;
import java.io.PrintWriter;

public class DeleteClass implements Action {
    private String userId = null;
    private String classId = null;

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getClassId() {
        return classId;
    }

    public void setClassId(String classId) {
        this.classId = classId;
    }

    @Override
    public String execute() throws Exception {

        UpdateData updateData = new UpdateData();
        try{
            updateData.Update("DELETE FROM CourseRecord WHERE CourseId =\'" +
            classId + "\' AND StudentNumber = \'" + userId + "\'");
        }catch (Exception e){
            System.out.println("选课表删除失败" + e);
            HttpServletResponse response = ServletActionContext.getResponse();
            response.setContentType("text/html;charset=utf-8");
            PrintWriter out = response.getWriter();
            out.print("<script>alert('连接服务器失败');window.location.href='course.html';</script>");
            return null;
        }

        HttpServletResponse response = ServletActionContext.getResponse();
        response.setContentType("text/html;charset=utf-8");
        PrintWriter out = response.getWriter();
        out.print("<script>alert('删除成功');window.location.href='course.html';</script>");

        return null;
    }
}
