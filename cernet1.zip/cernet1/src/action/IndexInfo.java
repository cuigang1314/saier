package action;

import mysql.SelectData;
import com.opensymphony.xwork2.Action;
import org.apache.struts2.ServletActionContext;

import javax.servlet.http.HttpServletResponse;
import java.io.PrintWriter;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;


public class IndexInfo implements Action{

    private List<String> lists = new ArrayList<String>();

    public List<String> getLists() {
        return lists;
    }

    public void setLists(List<String> lists) {
        this.lists = lists;
    }

    @Override
    public String execute() throws Exception {

        ResultSet resultSet = null;
        SelectData selectData = new SelectData();
        try{
            resultSet = selectData.Select("SELECT * from CourseTable");
        }catch (Exception e){
            System.out.println("课程表查询失败" + e);
            HttpServletResponse response = ServletActionContext.getResponse();
            response.setContentType("text/html;charset=utf-8");
            PrintWriter out = response.getWriter();
            out.print("<script>alert('连接服务器失败');window.location.href='login.html';</script>");
            return null;
        }
        int count = 0;
        while(resultSet.next()){
                lists.add(resultSet.getString("CourseName"));
                lists.add(resultSet.getString("CourseDescription"));
                lists.add(resultSet.getString("CourseId"));
                count += 1;
        }

        for(int i = count; i < 9; i++){
            lists.add("正在建设中。。。。。");
            lists.add("正在建设中，敬请期待！");
            lists.add("0");
        }
        return SUCCESS;
    }
}
