package action;

import mysql.SelectData;
import com.opensymphony.xwork2.Action;
import mysql.UpdateData;
import org.apache.struts2.ServletActionContext;
import javax.servlet.http.HttpServletResponse;
import java.io.PrintWriter;
import java.sql.*;

public class CourseRecord implements Action {
    private String courseId = null;
    private String stuId = null;

    public String getCourseId() {
        return courseId;
    }

    public void setCourseId(String courseId) {
        this.courseId = courseId;
    }

    public String getStuId() {
        return stuId;
    }

    public void setStuId(String stuId) {
        this.stuId = stuId;
    }

    @Override
    public String execute() throws Exception {

        SelectData selectData = new SelectData();
        UpdateData updateData = new UpdateData();
        ResultSet resultSet = null;
        try {
            resultSet = selectData.Select("SELECT * FROM COURSERECORD WHERE StudentNumber " +
                    "= \'" + stuId + "\' and CourseId = \'" + courseId + "\';"
            );
            if(resultSet.next() == true){
                HttpServletResponse response = ServletActionContext.getResponse();
                response.setContentType("text/html;charset=utf-8");
                PrintWriter out = response.getWriter();
                out.print("<script>alert('已选该课');location.href='classlearn.html?courseId=" + courseId + "\';</script>");
                return null;
            }
            updateData.Update("INSERT INTO CourseRecord VALUES (\'" + stuId +"\',\'" +
                    courseId + "\');");
            try{
                HttpServletResponse response = ServletActionContext.getResponse();
                response.setContentType("text/html;charset=utf-8");
                PrintWriter out = response.getWriter();
                out.print("<script>alert('选课成功');location.href='classlearn.html?courseId=" + courseId + "\';</script>");
                return null;
            }catch (Exception e){
                System.out.println("alert语句执行错误 " + e);
                HttpServletResponse response = ServletActionContext.getResponse();
                response.setContentType("text/html;charset=utf-8");
                PrintWriter out = response.getWriter();
                out.print("<script>alert('连接服务器失败');location.href='classlearn.html?courseId=" + courseId + "\';</script>");
                return null;
            }
        } catch (ClassNotFoundException e) {
            System.out.println("连接数据库" + e.toString());
            HttpServletResponse response = ServletActionContext.getResponse();
            response.setContentType("text/html;charset=utf-8");
            PrintWriter out = response.getWriter();
            out.print("<script>alert('连接服务器失败');location.href='classlearn.html?courseId=" + courseId + "\';</script>");
            return null;
        } catch (SQLException e) {
            System.out.println("执行数据库查询语句失败" + e.toString());
            HttpServletResponse response = ServletActionContext.getResponse();
            response.setContentType("text/html;charset=utf-8");
            PrintWriter out = response.getWriter();
            out.print("<script>alert('执行数据库语句失败');location.href='classlearn.html?courseId=" + courseId + "\';</script>");
            return null;
        } catch (Exception e) {
            //返回值 统一处理错误
            System.out.println("执行数据库语句失败" + e.toString());
            HttpServletResponse response = ServletActionContext.getResponse();
            response.setContentType("text/html;charset=utf-8");
            PrintWriter out = response.getWriter();
            out.print("<script>alert('连接数据库失败');location.href='classlearn.html?courseId=" + courseId + "\';</script>");
            return null;
        }
    }
}
