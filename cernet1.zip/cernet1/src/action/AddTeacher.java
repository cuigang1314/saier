package action;

import mysql.UpdateData;

import com.opensymphony.xwork2.Action;
import org.apache.struts2.ServletActionContext;
import javax.servlet.http.HttpServletResponse;
import java.io.PrintWriter;
import java.sql.SQLException;

public class AddTeacher implements Action {

    private String teanumber = null;
    private String teaname = null;
    private String teacollege = null;
    private String teaprofession = null;
    private String teamail = null;

    public String getTeanumber() {
        return teanumber;
    }

    public void setTeanumber(String teanumber) {
        this.teanumber = teanumber;
    }

    public String getTeaname() {
        return teaname;
    }

    public void setTeaname(String teaname) {
        this.teaname = teaname;
    }

    public String getTeacollege() {
        return teacollege;
    }

    public void setTeacollege(String teacollege) {
        this.teacollege = teacollege;
    }

    public String getTeaprofession() {
        return teaprofession;
    }

    public void setTeaprofession(String teaprofession) {
        this.teaprofession = teaprofession;
    }

    public String getTeamail() {
        return teamail;
    }

    public void setTeamail(String teamail) {
        this.teamail = teamail;
    }

    @Override
    public String execute() throws Exception {
        UpdateData updateData = new UpdateData();
        try {
            updateData.Update("INSERT INTO TeacherTable VALUES (\'" + teanumber + "\',\'" +
                    teaname + "\',\'" +
                    teanumber + "\',\'" +
                    teacollege + "\',\'" +
                    teaprofession + "\',\'" +
                    teamail +  "\',0" + ",0" + ",0 " + ")"
            );
        } catch (ClassNotFoundException e) {
            System.out.println("连接数据库" + e.toString());
            HttpServletResponse response = ServletActionContext.getResponse();
            response.setContentType("text/html;charset=utf-8");
            PrintWriter out = response.getWriter();
            out.print("<script>alert('连接数据库失败');window.location.href='adminuser.html';</script>");
            return null;
        } catch (SQLException e) {
            System.out.println("执行数据库查询语句失败" + e.toString());
            HttpServletResponse response = ServletActionContext.getResponse();
            response.setContentType("text/html;charset=utf-8");
            PrintWriter out = response.getWriter();
            out.print("<script>alert('执行数据库语句失败');window.location.href='adminuser.html';</script>");
            return null;
        } catch (Exception e) {
            //返回值 统一处理错误
            System.out.println("执行数据库语句失败" + e.toString());
            HttpServletResponse response = ServletActionContext.getResponse();
            response.setContentType("text/html;charset=utf-8");
            PrintWriter out = response.getWriter();
            out.print("<script>alert('连接数据库失败');window.location.href='adminuser.html';</script>");
            return null;
        }
        HttpServletResponse response = ServletActionContext.getResponse();
        response.setContentType("text/html;charset=utf-8");
        PrintWriter out = response.getWriter();
        out.print("<script>alert('成功注册');window.location.href='adminuser.html';</script>");
        return null;
    }
}
