package action;

import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import com.opensymphony.xwork2.Action;
import mysql.SelectData;
import org.apache.struts2.ServletActionContext;

import javax.servlet.http.HttpServletRequest;

public class AdminQuery implements Action {

    @Override
    public String execute() throws Exception {

        ArrayList<Map<String,Object>> list = new ArrayList<>();
        ResultSet resultSet = null;
        String sqlSentence = "Select * from studenttable where request = '1'; ";
        try{
            SelectData selectData = new SelectData();
            resultSet = selectData.Select(sqlSentence);
        }catch (Exception e){
            e.printStackTrace();
            return "failed";
        }
        while (resultSet.next()) {
            Map map = new HashMap<String, Object>();
            map.put("number", resultSet.getString("studentnumber"));
            map.put("name", resultSet.getString("studentname"));
            map.put("college", resultSet.getString("college"));
            map.put("profession", resultSet.getString("profession"));
            map.put("mail", resultSet.getString("mail"));
            map.put("type","1");
            list.add(map);
        }
        sqlSentence = "Select * from teachertable where request = '1'; ";
        try{
            SelectData selectData = new SelectData();
            resultSet = selectData.Select(sqlSentence);
        }catch (Exception e){
            e.printStackTrace();
            return "failed";
        }
        while (resultSet.next()) {
            Map map = new HashMap<String, Object>();
            map.put("number", resultSet.getString("teachernumber"));
            map.put("name", resultSet.getString("teachername"));
            map.put("college", resultSet.getString("college"));
            map.put("profession", resultSet.getString("profession"));
            map.put("mail", resultSet.getString("mail"));
            map.put("type","2");
            list.add(map);
        }
        HttpServletRequest request = ServletActionContext.getRequest();
        request.setAttribute("list",list);
        return "success";
    }
}
