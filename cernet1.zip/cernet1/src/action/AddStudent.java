package action;

/***
 *
 * return "error" 标识 系统错误信息处理
 *
 * @author yh
 */

import com.opensymphony.xwork2.Action;
import mysql.UpdateData;
import org.apache.struts2.ServletActionContext;

import javax.servlet.http.HttpServletResponse;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class AddStudent implements Action {

    private String stunumber = null;
    private String stuname = null;
    private String stucollege = null;
    private String stuprofession = null;
    private String stumail = null;

    public String getStunumber() {
        return stunumber;
    }

    public void setStunumber(String stunumber) {
        this.stunumber = stunumber;
    }

    public String getStuname() {
        return stuname;
    }

    public void setStuname(String stuname) {
        this.stuname = stuname;
    }

    public String getStucollege() {
        return stucollege;
    }

    public void setStucollege(String stucollege) {
        this.stucollege = stucollege;
    }

    public String getStuprofession() {
        return stuprofession;
    }

    public void setStuprofession(String stuprofession) {
        this.stuprofession = stuprofession;
    }

    public String getStumail() {
        return stumail;
    }

    public void setStumail(String stumail) {
        this.stumail = stumail;
    }

    @Override
    public String execute() throws Exception {

        UpdateData updateData = new UpdateData();
        try {
            updateData.Update("INSERT INTO StudentTable VALUES (\'" + stunumber +"\',\'" +
                    stuname + "\',\'" +
                    stunumber + "\',\'" +
                    stucollege + "\',\'" +
                    stuprofession + "\',\'" +
                    stumail + "\',0" + ",0" + ",0 " + ")"
            );
        } catch (ClassNotFoundException e) {
            System.out.println("连接数据库" + e.toString());
            HttpServletResponse response = ServletActionContext.getResponse();
            response.setContentType("text/html;charset=utf-8");
            PrintWriter out = response.getWriter();
            out.print("<script>alert('连接数据库失败');window.location.href='register.html';</script>");
            return null;
        } catch (SQLException e) {
            System.out.println("执行数据库查询语句失败" + e.toString());
            HttpServletResponse response = ServletActionContext.getResponse();
            response.setContentType("text/html;charset=utf-8");
            PrintWriter out = response.getWriter();
            out.print("<script>alert('执行数据库语句失败');window.location.href='register.html';</script>");
            return null;
        } catch (Exception e) {
            //返回值 统一处理错误
            System.out.println("执行数据库语句失败" + e.toString());
            HttpServletResponse response = ServletActionContext.getResponse();
            response.setContentType("text/html;charset=utf-8");
            PrintWriter out = response.getWriter();
            out.print("<script>alert('连接数据库失败');window.location.href='register.html';</script>");
            return null;
        }
        HttpServletResponse response = ServletActionContext.getResponse();
        response.setContentType("text/html;charset=utf-8");
        PrintWriter out = response.getWriter();
        out.print("<script>alert('成功注册');window.location.href='login.html';</script>");
        return null;
    }
}
