
package action;

import com.opensymphony.xwork2.Action;
import mysql.SelectData;
import mysql.UpdateData;
import org.apache.struts2.ServletActionContext;

import javax.servlet.http.HttpServletResponse;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class Register implements Action {
    private String number = null;
    private String pwd = null;
    private String major = null;
    private String name = null;
    private String academy = null;
    private String email = null;
    private String radio = null;

    public String getRadio() {
        return radio;
    }

    public void setRadio(String radio) {
        this.radio = radio;
    }

    public String getNumber() {
        return number;
    }

    public void setNumber(String number) {
        this.number = number;
    }

    public String getPwd() {
        return pwd;
    }

    public void setPwd(String pwd) {
        this.pwd = pwd;
    }

    public String getMajor() {
        return major;
    }

    public void setMajor(String major) {
        this.major = major;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAcademy() {
        return academy;
    }

    public void setAcademy(String academy) {
        this.academy = academy;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    @Override
    public String execute() throws Exception {

        ResultSet resultSet = null;
        UpdateData updateData = new UpdateData();
        SelectData selectData = new SelectData();
        try{
            if(radio.equals("one"))
                resultSet = selectData.Select("select password from studenttable Where " +
                    "StudentNumber = \'" + this.number + "\'");
            else if(radio.equals("two"))
                resultSet = selectData.Select("Select password from TeacherTable Where " +
                        "TeacherNumber  = \'" + this.number + "\'");
        }catch (Exception e){

            System.out.println("执行数据库查询语句失败" + e.toString());
            if(resultSet != null)
                resultSet.close();
            HttpServletResponse response = ServletActionContext.getResponse();
            response.setContentType("text/html;charset=utf-8");
            PrintWriter out = response.getWriter();
            out.print("<script>alert('注册失败');window.location.href='register.html';</script>");
            return null;
        }
        if(resultSet == null || resultSet.next() == false){

            if(radio.equals("one"))
                updateData.Update("Insert Into StudentTable Values(\'" + this.number +
                            "\',\'" + this.name + "\',\'" + this.pwd + "\',\'" + this.academy +
                            "\',\'" + this.major + "\',\'" + this.email + "\',0" + ",0" + ",0 " + ")");
            else if(radio.equals("two"))
                updateData.Update("Insert Into TeacherTable Values(\'" + this.number +
                        "\',\'" + this.name + "\',\'" + this.pwd + "\',\'" + this.academy +
                        "\',\'" + this.major + "\',\'" + this.email + "\',0" + ",0" + ",0" + ")");
            resultSet.close();
            return "1";
        }

        //添加用户失败 用户已存在
        HttpServletResponse response = ServletActionContext.getResponse();
        response.setContentType("text/html;charset=utf-8");
        PrintWriter out = response.getWriter();
        out.print("<script>alert('用户已存在');window.location.href='register.html';</script>");
        return null;
    }
}
