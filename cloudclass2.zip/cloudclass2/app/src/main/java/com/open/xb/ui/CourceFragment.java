package com.open.xb.ui;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.LinearLayout;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.handmark.pulltorefresh.library.PullToRefreshBase;
import com.handmark.pulltorefresh.library.PullToRefreshScrollView;
import com.loopj.android.http.AsyncHttpClient;
import com.nostra13.universalimageloader.core.ImageLoader;
import com.nostra13.universalimageloader.core.ImageLoaderConfiguration;
import com.open.xb.R;
import com.open.xb.adapter.CourceAdapter;
import com.open.xb.bean.CBanner;
import com.open.xb.bean.VideoInfo;
import com.open.xb.widght.CycleView;
import com.open.xb.widght.McListView;
import com.open.xb.widght.WebActivity;

import java.util.List;

import butterknife.ButterKnife;
import butterknife.InjectView;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

/**
 * Created by bai on 2018/6/21.
 */
public class CourceFragment extends Fragment implements PullToRefreshBase.OnRefreshListener2, AdapterView.OnItemClickListener{

    @InjectView(R.id.search)
    ImageView search;
    @InjectView(R.id.banner_view)
    CycleView bannerView;
    @InjectView(R.id.container_bottom)
    LinearLayout containerBottom;
    @InjectView(R.id.refresh_view)
    PullToRefreshScrollView refreshView;
    @InjectView(R.id.cource_listView)
    McListView listView;
    private View view;
    private CourceAdapter courceAdapter;
    AsyncHttpClient client = new AsyncHttpClient();
//    private CourceBottomView courceBottomView;
//    private String timestamp = "1450167252147";
//    private String token = "7f75e24cb1f7e5c358f03a7b40a60976";
//    private int pageIndex = 0;
//    private String uid = "0";
//    private int currentPage = 0;

    private  static  List<VideoInfo> courcelist;
    private  static  List<CBanner> cbannerlist;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.activity_tab_cource, null, false);
        ButterKnife.inject(this, view);
        init();
        return view;
    }

    private void init() {
        getBannerData();
        initView();

        //getCourceListData();
    }





//    private McFlipTextView.ItemDataListener itemListener = new McFlipTextView.ItemDataListener() {
//        @Override
//        public void onItemClick(int position) {
//            Intent intent=new Intent(getActivity(), WebActivity.class);
//            intent.putExtra("title", list.get(position).title);
//            intent.putExtra("url",list.get(position).url);
//            startActivity(intent);
//        }
//    };

    private void initView() {
        getCourceListData();
        courceAdapter=new CourceAdapter(getActivity(),courcelist);
        listView.setAdapter(courceAdapter);
        listView.setOnItemClickListener(this);

        refreshView.setOnRefreshListener(this);
        refreshView.setScrollingWhileRefreshingEnabled(true);
        refreshView.setLastPage(true);
    }
    private void getBannerData() {
        Thread thread=   new Thread(new Runnable() {
            @Override
            public void run() {

                OkHttpClient client = new OkHttpClient();
                try {
                    Request request = new Request.Builder().url("http://10.0.2.2:8080/spring/queryimg.html").build();
                    Response response = client.newCall(request).execute();
                    String responseData = response.body().string();
                    System.out.println("**********************************" + responseData);
                    Gson gson = new Gson();
//                  List userlist=new ArrayList<User>();

                    cbannerlist = gson.fromJson(responseData, new TypeToken<List<CBanner>>() {
                    }.getType());

                    for (CBanner cbanner : cbannerlist) {
                        Log.d("info:", cbanner.getImgurl());
                        // Log.d("info:",book.getBook_name());

                        String imgurl = cbanner.getImgurl();
//                        String videopic = videoInfo.getPic();
//                        String videodesc = videoInfo.getDesc();
//                        String videoUrl = videoInfo.getVideoUrl();

//                            List<CBanner> list = cbanner.data;
                            System.out.println("qqqq"+cbannerlist);
                            bannerView.setImageResources(cbannerlist, listener);

                    }

                } catch (Exception e){
                    e.printStackTrace();
                }
            }
        }) ;
        thread.start();
        //阻塞Main线程，执行子线程workThread1和workThread2，完毕后继续执行后续的逻辑
        try {
            thread.join();

        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
//    private void getBannerData1() {
//        String url = Contants.COURCE_BANNER;
//        RequestParams params = new RequestParams();
//        params.put("uid", "0");
//        params.put("marking", "banner");
//        params.put("token", "8301d54bbde33ffc9cce3317a51ecd13");
//        client.post(url, params, new AsyncHttpResponseHandler() {
//            @Override
//            public void onSuccess(String content) {
//                if(refreshView!=null){
//                    refreshView.onRefreshComplete();
//                }
//                if (content != null) {
////                    Gson gson=new Gson();
////                    courcelist =gson.fromJson(content,new TypeToken<List<CourceBanner>>(){}.getType());
////                    List<CourceBanner> bannner = gson.fromJson(content,CourceBanner.class);
//////                    CourceBanner banner = JsonUtil.parseJson(content, CourceBanner.class);
//////
//                    CourceBanner banner = JsonUtil.parseJson(content, CourceBanner.class);
//                    if (banner != null) {
//                        List<CourceBanner.BannerItem> list = banner.data;
//                        bannerView.setImageResources(list, listener);
//                    }
//                }
//            }

//            @Override
//            public void onFailure(Throwable error, String content) {
//                super.onFailure(error, content);
//                if (refreshView!=null)
//                refreshView.onRefreshComplete();
//                Toast.makeText(getActivity(), content, Toast.LENGTH_LONG).show();
//            }
//        });
//    }


    private void getCourceListData() {
        Thread thread=   new Thread(new Runnable() {
            @Override
            public void run() {

                OkHttpClient client = new OkHttpClient();
                try{
                    Request request = new Request.Builder().url("http://10.0.2.2:8080/spring/video.html").build();
                    Response response = client.newCall(request).execute();
                    String responseData =response.body().string();
                    System.out.println("**********************************"+responseData);
                    Gson gson=new Gson();
//                  List userlist=new ArrayList<User>();

                     courcelist =gson.fromJson(responseData,new TypeToken<List<VideoInfo>>(){}.getType());

                    for(VideoInfo videoInfo : courcelist)
                    {
                        Log.d("info:",videoInfo.getPic());
                        // Log.d("info:",book.getBook_name());
                        String videoname = videoInfo.getName();
                        String videopic = videoInfo.getPic();
                        String videodesc = videoInfo.getDesc();
                        String videoUrl = videoInfo.getVideoUrl();

                    }

//            @Override
//            public void onSuccess(String content) {
//                if (content != null) {
//                    if (refreshView!=null)
//                        refreshView.onRefreshComplete();
//                    CourceList list = JsonUtil.parseJson(content, CourceList.class);
//                    if (list != null && list.data.size() > 0) {
//                     List<CourceList.CourceData> courselist = ;

//            courceAdapter.setList();
//                        addBottomView(list);
//                    }
//                }
//            }
//            @Override
//            public void onFailure(Throwable error, String content) {
//                super.onFailure(error, content);
//                if (refreshView!=null)
//                    refreshView.onRefreshComplete();
//                Toast.makeText(getActivity(), content, Toast.LENGTH_LONG).show();
//            }
                } catch (Exception e){
                    e.printStackTrace();
                }
            }
        }) ;
        thread.start();
        //阻塞Main线程，执行子线程workThread1和workThread2，完毕后继续执行后续的逻辑
        try {
            thread.join();

        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    private CycleView.CycleViewListener listener = new CycleView.CycleViewListener() {
        @Override
        public void displayImage(String imageURL, ImageView imageView) {
            ImageLoader.getInstance().init(ImageLoaderConfiguration.createDefault(getActivity()));
            ImageLoader.getInstance().displayImage(imageURL, imageView);
        }

        @Override
        public void onImageClick(CBanner info, int postion, View imageView) {
            Intent intent=new Intent(getActivity(), WebActivity.class);
            intent.putExtra("title", "广告");
//            intent.putExtra("url",);
            startActivity(intent);
        }
    };


    @Override
    public void onDestroyView() {
        super.onDestroyView();
        ButterKnife.reset(this);
    }


    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        String videoUri=courcelist.get(position).getVideoUrl();

        Intent intent=new Intent(getActivity(), ChangeClarityActivity.class);
        intent.putExtra("url",videoUri);
        startActivity(intent);
    }

    @Override
    public void onPullDownToRefresh(PullToRefreshBase refreshView) {
//        getBannerData();
        getCourceListData();
    }

    @Override
    public void onPullUpToRefresh(PullToRefreshBase refreshView) {
//        getBannerData();
        getCourceListData();
    }
}
