package com.open.xb.ui;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TabHost;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.open.xb.R;
import com.open.xb.base.BaseActivity;
import com.open.xb.bean.User;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

import okhttp3.FormBody;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;
/**
 * Created by bai on 2018/6/15.
 */

public class LoginActivity extends BaseActivity  {
    TextView responsetext;
    private EditText username_et;
    private EditText password_et;
    private String username =null;
    private String password = null;
    private SharedPreferences.Editor editor;
    private SharedPreferences sp;
//    private User user;
    public static final MediaType JSON = MediaType.parse("application/json; charset=utf-8");
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        Button login = (Button)findViewById(R.id.login);
        TextView register = (TextView)findViewById(R.id.register);
        username_et = (EditText)findViewById(R.id.username_et);
        System.out.println("@HJKLKJKLK"+username_et);
        password_et = (EditText)findViewById(R.id.password_et);
        responsetext = (TextView)findViewById(R.id.response_text);
        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                username = username_et.getText().toString();
                password = password_et.getText().toString();
                if(username.equals("")||password.equals("")){
                    Toast.makeText(LoginActivity.this,"用户名或密码不能为空！",Toast.LENGTH_SHORT).show();
                }
                send();
            }
        });
        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(LoginActivity.this,RegisterActivity.class);
                startActivity(intent);
            }
        });
    }
    private void send(){
        new Thread(new Runnable() {
            @Override
            public void run() {
                try{
                    username = username_et.getText().toString();
                    password = password_et.getText().toString();

                    OkHttpClient client = new OkHttpClient();
//                    Gson gson = new Gson();
//
//                    User user  = new User();
//                    user.setUsername(username);
//                    user.setPassword(password);
//                    String json = gson.toJson(user);
//                    RequestBody body = RequestBody.create(JSON, json);
                    RequestBody requestBody = new FormBody.Builder()
                            .add("UserName",username)
                            .add("PassWord",password).build();
                    Request request = new Request.Builder().url("http://10.0.2.2:8080/spring/logining.html").post(requestBody).build();
                    Response response = client.newCall(request).execute();
                    String responseData =response.body().string();

                    Gson gson=new Gson();
//                  List userlist=new ArrayList<User>();

                  List<User> userlist =gson.fromJson(responseData,new TypeToken<List<User>>(){}.getType());

                    for(User user : userlist)
                    {
                        Log.d("info:",user.getAvatar());
                         String avatar1= user.getAvatar();
                         String id1 = user.getId();
                        // 完成sp的初始化。
                        sp = getSharedPreferences("config", MODE_PRIVATE);
                        SharedPreferences.Editor editor = sp.edit();
                        editor.putString("id",id1);
                        editor.putString("avatar",avatar1);
                        editor.commit();
                        String saved = sp.getString("id", "");
                        Log.d("infoid:",saved);

                    }
                        // Log.d("info:",book.getBook_name());
//                    String name= userlist.get(1).toString();

                   if(userlist.size()>0)
                   {
                       Intent intent = new Intent(LoginActivity.this,MainActivity.class);
                       intent.putExtra("username","name");
                       startActivity(intent);
                   }
                   else{
                       showResponse();
                   }

                    /*   Response response = client.newCall(request).execute();
                    String responsedata = response.body().string();
                    System.out.println(responsedata);*/
//                    // 完成sp的初始化。
//                    sp = getSharedPreferences("config", MODE_PRIVATE);
////获取sp里面存储的数据
//                    String savedid = sp.getString("username", "");
//                    String savedPassword = sp.getString("password", "");
//                    username_et.setText(savedid);
//                    password_et.setText(savedPassword);
//                    SharedPreferences.Editor editor = sp.edit();
//                    editor.putString("acc", username);
//                    editor.putString("password", password);
//                    editor.putString("avatar",responsedata);
//                    editor.commit();

//                    User user = gson.fromJson(responsedata, User.class);
//                    JSONObject jsonObject = new JSONObject(responsedata);
                    /*JSONArray jsonArray = new JSONArray(responsedata);
                    for (int i = 0; i < jsonArray.length(); i++) {
                        JSONObject jsonObject = jsonArray.getJSONObject(i);
                        String nick = jsonObject.getString("nickname");
                        if(nick!=null){
//                        SharedPreferences spf = getSharedPreferences("user_info", MODE_PRIVATE);
//                        spf.edit().putString("password", userInfo.getPassword())
//                                .putString("nickname", userInfo.getNickname())
//                                .putString("avatar", userInfo.getAvatar())
//                                .apply();


                    }*/
                    }



//                    User user1 = gson.fromJson(jsonObject.getString("nickname"), User.class);
//                    System.out.println("user");
//                    String nick = user1.getNickname();
                    //登录成功的话 更新一下用户信息到本地

                catch (Exception e){
                    e.printStackTrace();
                }
            }
        }).start();
    }
    private void showResponse(){
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                Toast.makeText(LoginActivity.this,"用户名或密码错误！",Toast.LENGTH_SHORT).show();
            }
        });
    }
}
