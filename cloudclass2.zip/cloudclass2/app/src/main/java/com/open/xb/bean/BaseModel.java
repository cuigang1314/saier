package com.open.xb.bean;

/**
 * Created by bai on 2018/6/20.
 */
public class BaseModel  {
     public int status;
     public int errorCode;
     public String errorDesc;
     public String timestamp;
     public String hash;
}
