package com.open.xb.ui;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.open.xb.R;
import com.open.xb.base.BaseActivity;
import com.open.xb.bean.User;

import java.util.List;

import butterknife.ButterKnife;
import butterknife.OnClick;
import okhttp3.FormBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;
/**
 * Created by bai on 2018/6/16.
 */
public class SettingActivity extends BaseActivity {
    private String avatarUrl;
    private String nickname;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.setting_layout);
        ButterKnife.inject(this);
    }
    @OnClick(R.id.query)
    public void queryClick(View view){

        Intent intent = new Intent(SettingActivity.this,UserActivity.class);
        startActivity(intent);
                }
    @OnClick(R.id.logout)
    public void backClick(View view){
         finish();
    }
    @OnClick (R.id.baeeage)
    public void baeeageClick(View view){
        startActivity(new Intent(this,BaeeageActivity.class));
    }

}
