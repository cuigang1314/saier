package com.open.xb.ui.fragment;


import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.LinearLayout;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.handmark.pulltorefresh.library.PullToRefreshBase;
import com.handmark.pulltorefresh.library.PullToRefreshListView;
import com.open.xb.R;
import com.open.xb.adapter.ArticleAdapter;
import com.open.xb.bean.ArticleModel;
import com.open.xb.widght.WebActivity;

import java.util.List;

import butterknife.ButterKnife;
import butterknife.InjectView;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

/**
 * Created by bai on 2018/6/20.
 */
public class ArticlesFragment extends Fragment implements PullToRefreshBase.OnRefreshListener2, AdapterView.OnItemClickListener{


    //@InjectView(R.id.empty_view)
  //  LinearLayout emptyView;

    private String token = "aec1e1fe6da2e8a4ba9d7b725d851f57";
    private int type=0;
    private int aid = 0;
    private String uid = "0";
    private int page=0;
    private int typeid=0;

    private ArticleAdapter adapter;
    private  static  List<ArticleModel> artlist;
    @InjectView(R.id.article_listview)
    PullToRefreshListView listView;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_community_articles, null);
        ButterKnife.inject(this, view);
        initView();
      /*  int i=artlist.size();
        Log.d("qazwsxqazwsx:",String.valueOf(i));*/
        return view;
    }

    private void initView() {
//        emptyView.setVisibility(View.GONE);
        getData();
        adapter=new ArticleAdapter(getActivity(),artlist);
        listView.setAdapter(adapter);
        listView.setOnRefreshListener(this);
        listView.setScrollingWhileRefreshingEnabled(true);
        listView.setLastPage(true);
        listView.setOnItemClickListener(this);
    }
//    private void getData() {
//        String url = Contants.GET_ACTIVE_DATA;
//        RequestParams params = new RequestParams();
//        params.put("uid",uid);
//        params.put("aid",aid+"");
//        params.put("type",type+"");
//        params.put("page",page+"");
//        params.put("typeid",typeid+"");
//        params.put("token",token);
//        client.post(url, params, new AsyncHttpResponseHandler() {
//            @Override
//            public void onSuccess(String content) {
//                if (listView != null)
//                    listView.onRefreshComplete();
//                if (content != null) {
//                    articleModel = JsonUtil.parseJson(content, ArticleModel.class);
//                    if (articleModel != null) {
//                        bindData(articleModel.data);
//                    }
//                }
//            }
private void getData() {

    Thread thread=   new Thread(new Runnable() {
        @Override
        public void run() {
            OkHttpClient client = new OkHttpClient();
            try {
                Request request = new Request.Builder().url("http://10.0.2.2:8080/spring/arting.html").build();
                Response response = client.newCall(request).execute();
                String responseData = response.body().string();
                System.out.println("**********************************" + responseData);
                Gson gson = new Gson();
//                  List userlist=new ArrayList<User>();

                artlist = gson.fromJson(responseData, new TypeToken<List<ArticleModel>>() {
                }.getType());
                System.out.println("!@3456" + artlist.toString());

                for (ArticleModel article : artlist) {
                    Log.d("info:", article.getUrl());
                    // Log.d("info:",book.getBook_name());
                    String artImg = article.getImg();
                    String artTitle = article.getTitle();
                    String artUrl = article.getUrl();

                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }) ;
    thread.start();
    //阻塞Main线程，执行子线程workThread1和workThread2，完毕后继续执行后续的逻辑
    try {
        thread.join();

    } catch (InterruptedException e) {
        e.printStackTrace();
    }

}


//    private void bindData(List data) {
//        if (aid == 0) adapter.clear();
//        listView.setLastPage(data == null);
//        adapter.addList(data);
//        if (adapter.getCount() == 0) {
//            listView.setVisibility(View.GONE);
//            emptyView.setVisibility(View.VISIBLE);
//        } else {
//            listView.setVisibility(View.VISIBLE);
//            emptyView.setVisibility(View.GONE);
//        }
//        ArticleModel item = adapter.getLastItem();
//        if (item != null) {
//            aid=item.id;
//        }
//        ++page;
//    }


    @Override
    public void onDestroyView() {
        super.onDestroyView();
        ButterKnife.reset(this);
    }

    @Override
    public void onPullDownToRefresh(PullToRefreshBase refreshView) {
        aid = 0;
        page=0;
        getData();
    }

    @Override
    public void onPullUpToRefresh(PullToRefreshBase refreshView) {
         getData();
    }

    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        String artUri=artlist.get(position).getUrl();
        System.out.println("12345654322"+artUri);
        Intent intent=new Intent(getActivity(), WebActivity.class);
        intent.putExtra("title", "文章");
        intent.putExtra("url",artUri);
        startActivity(intent);

    }
}