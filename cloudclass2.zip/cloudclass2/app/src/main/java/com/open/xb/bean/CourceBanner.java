package com.open.xb.bean;

import java.util.List;

/**
 * Created by bai on 2018/6/20.
 */
public class CourceBanner extends BaseModel {
//    public List<BannerItem> data;
//
//    public class BannerItem{
//       public int id;
//        public int type;
//        public int type_id;
//        public String name;
//        public String pic;
//        public String links;
//    }
}
