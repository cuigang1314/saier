package com.open.xb.base.imageCache;

public interface CallBackHandler {
	void onCallBack();
}
