package com.open.xb.bean;

import java.util.List;

/**
 * Created by bai on 2018/7/4.
 */

public class CBanner {
    public int id;
    public List<CBanner> data;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getImgurl() {
        return imgurl;
    }

    public void setImgurl(String imgurl) {
        this.imgurl = imgurl;
    }

    public String imgurl;
}
