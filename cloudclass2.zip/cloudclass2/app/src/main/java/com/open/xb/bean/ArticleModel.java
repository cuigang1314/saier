package com.open.xb.bean;

import com.open.xb.bean.BaseModel;

import java.util.List;

/**
 * Created by bai on 2018/6/20.
 */
public class ArticleModel {

        public String id;
        public String title;
        public String desc;
        public String img;
        public String url;
        public String getId() {
            return id;
        }

        public void setId(String id) {
            this.id = id;
        }

        public String getTitle() {
            return title;
        }

        public void setTitle(String title) {
            this.title = title;
        }

        public String getImg() {
            return img;
        }

        public void setImg(String img) {
            this.img = img;
        }

        public String getUrl() {
            return url;
        }

        public void setUrl(String url) {
            this.url = url;
        }
}
