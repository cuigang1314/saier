package com.open.xb.bean;

import com.open.xb.bean.BaseModel;

import java.util.List;

/**
 * Created by bai on 2018/6/20.
 */
public class ActiveModel  {
    public List<ActiveItem> data;

    public class ActiveItem{
        public int id;
        public String name;
    }
}
