package com.open.xb.bean;

/**
 * Created by bai on 2018/6/20.
 */
public class MineModel {
    public String name;
    public int image;
}
