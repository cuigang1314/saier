package com.open.xb.adapter;

import android.app.Activity;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.open.xb.R;
import com.open.xb.base.BasicAdapter;
import com.open.xb.base.imageCache.ImageCache;
import com.open.xb.bean.ArticleModel;


import java.util.List;

import butterknife.ButterKnife;
import butterknife.InjectView;

public class ArticleAdapter extends BaseAdapter {

    private Activity context;
    private List<ArticleModel> list;
    public ArticleAdapter(Activity context, List<ArticleModel> artlist) {
        this.context = context;
        list=artlist;
        int i=list.size();
        Log.d("qazwsx:",String.valueOf(i));
    }
    public List<ArticleModel> getList() {
        return list;
    }

    public void setList(List<ArticleModel> list) {
        this.list = list;
        notifyDataSetChanged();
    }
    @Override
    public int getCount() {
        if(list!=null){
            return list.size();
        }else
            return 0;
    }
    @Override
    public ArticleModel getItem(int position) {
        return list.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }


    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder viewHolder = null;
        if (convertView == null) {
            convertView = View.inflate(context, R.layout.article_item_layout, null);
            viewHolder = new ViewHolder(convertView);
        } else {
            viewHolder = (ViewHolder) convertView.getTag();
        }
        ArticleModel item = list.get(position);
        if (item == null) {
            return null;
        } else {
            initItemView(viewHolder, item);
        }

        return convertView;
    }

    private void initItemView(ViewHolder viewHolder, ArticleModel item) {
        ImageCache.display(context, item.img, viewHolder.articleImage);
        viewHolder.articleTitle.setText(item.title);
        viewHolder.articleDesc.setText(item.desc);
    }

    static class ViewHolder {
        @InjectView(R.id.article_title)
        TextView articleTitle;
        @InjectView(R.id.article_image)
        ImageView articleImage;
        @InjectView(R.id.article_desc)
        TextView articleDesc;
        @InjectView(R.id.content_layout)
        RelativeLayout contentLayout;

        ViewHolder(View view) {
            ButterKnife.inject(this, view);
            view.setTag(this);
        }

        public void reset() {
            articleTitle.setText("");
            articleDesc.setText("");
            articleImage.setBackgroundResource(R.drawable.xbstudyart);
        }
    }

}
