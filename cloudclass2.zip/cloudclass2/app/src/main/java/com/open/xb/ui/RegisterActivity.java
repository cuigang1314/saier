package com.open.xb.ui;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.open.xb.R;
/**
 * Created by bai on 2018/6/15.
 */
public class RegisterActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
    }
}
