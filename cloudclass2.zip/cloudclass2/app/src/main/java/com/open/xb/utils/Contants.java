package com.open.xb.utils;

/**
 * Created by bai on 2018/6/20.
 */
public class Contants {

    public static int DEFAULT_UID = 0;
    public static String GUIDE = "is_first";
    public static String CURR_FRAME_PAGER = "current_page";
    public static String IS_FIRST_USE = "first_use";


    public static String COURCE_BANNER = "http://www.imooc.com/api3/getadv";
//    public static String COURCE_LIST = "http://www.imooc.com/api3/courselist_ver2";
//    public static String COURCE_LIST1 = "http://10.0.2.2:8080/spring/logining.html";

//    public static String GET_ARTICLE_DATA = "http://www.imooc.com/api3/articlelist";
//    public static String GET_ACTIVE_DATA = "http://news-at.zhihu.com/api/4/";

//    //chapter章节
//    public static String GET_CHAPTER_INFO = "http://www.imooc.com/api3/getcpinfo_ver2";
//    public static String GET_COMMENT_INFO = "http://www.imooc.com/api3/coursecommentlist";

    public static String APSID="apsid";
}
