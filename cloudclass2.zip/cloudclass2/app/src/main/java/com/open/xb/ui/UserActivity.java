package com.open.xb.ui;

import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.open.xb.R;
import com.open.xb.bean.User;

import java.util.List;

import butterknife.OnClick;
import okhttp3.FormBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class UserActivity extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user);

        new Thread(new Runnable() {//开启新的线程
                @Override
                public void run() {
                try {
                    OkHttpClient client = new OkHttpClient();
                    SharedPreferences sp = getSharedPreferences("config", MODE_PRIVATE);
                    String userid = sp.getString("id","");//获取SharedPreferences 的id
                    System.out.println("@@@@@"+userid);
                    RequestBody requestBody = new FormBody.Builder()
                            .add("id", userid).build();
                    Request request = new Request.Builder().url("http://10.0.2.2:8080/spring/querying.html").post(requestBody).build();
                    Response response = client.newCall(request).execute();//接受请求
                    String responseData = response.body().string();//接受请求的数据
                    System.out.println(requestBody);
                    Gson gson = new Gson();
                    List<User> userlist = gson.fromJson(responseData, new TypeToken<List<User>>() {
                    }.getType());//json数据解析
                    for (User user : userlist) {
                        Log.d("info:", user.getAvatar());
                        String id = user.getId();
                        String username = user.getUsername();
                        String nickname = user.getNickname();
                        TextView text1 = (TextView) findViewById(R.id.ID);
                        text1.setText(id);
                        TextView text2 = (TextView) findViewById(R.id.username1);
                        text2.setText(username);
                        TextView text3 = (TextView) findViewById(R.id.nickname1);
                        text3.setText(nickname);

                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }).start();
    }
//    @OnClick(R.id.back)
//    public void backClick(View view){
//        finish();
//    }
}