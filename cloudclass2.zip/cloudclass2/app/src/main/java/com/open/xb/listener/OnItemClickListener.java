package com.open.xb.listener;

import android.view.View;

public interface OnItemClickListener {
   void onItem(View view, int position, int flag);
}
