var express = require('express');
var fs = require('fs');
var path = require("path");
var app = express();
var bodyParser = require('body-parser');

var roomList = require('./routes/roomList');
var cookieParser = require('cookie-parser');

var mysql  = require('mysql');  
 
var connection = mysql.createConnection({     
  host     : '127.0.0.1',       
  user     : 'root',              
  password : '000000',       
  port: '3306',                   
  database: 'videoclassroom', 
}); 
 
connection.connect();

var session = require('express-session');

var key = fs.readFileSync('keys/newkey.pem');
var cert = fs.readFileSync('keys/cert.pem');
//https密钥
var https_options = {
    key: key,
    cert: cert
};
var server = require('https').createServer(https_options,app);
var SkyRTC = require('skyrtc').listen(server);

var port = process.env.PORT || 443;
server.listen(port);

//配置请求头
app.all('*', function(req, res, next) {
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Headers", "X-Requested-With");
    res.header("Access-Control-Allow-Methods","PUT,POST,GET,DELETE,OPTIONS");
    res.header("X-Powered-By",' 3.2.1');
    next();
});


//配置公共资源文件夹
app.use(express.static(path.join(__dirname, 'public')));

//配置post请求
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));

//配置cookie
app.use(cookieParser());

//配置前端模版为ejs
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'ejs');

SkyRTC.rtc.on('new_connect', function(socket) {
    console.log('创建新连接');
});

SkyRTC.rtc.on('remove_peer', function(socketId) {
    roomList.leaveRoom(socketId);
    console.log(socketId + "用户离开");
});

SkyRTC.rtc.on('new_peer', function(socket, room) {
    roomList.enterRoomSocket(room, socket.id);
    console.log("新用户" + socket.id + "加入房间" + room);
});

SkyRTC.rtc.on('socket_message', function(socket, msg) {
    console.log("接收到来自" + socket.id + "的新消息：" + msg);
});

SkyRTC.rtc.on('ice_candidate', function(socket, ice_candidate) {
    console.log("接收到来自" + socket.id + "的ICE Candidate");
});

SkyRTC.rtc.on('offer', function(socket, offer) {
    console.log("接收到来自" + socket.id + "的Offer");
});

SkyRTC.rtc.on('answer', function(socket, answer) {
    console.log("接收到来自" + socket.id + "的Answer");
});

SkyRTC.rtc.on('error', function(error) {
    console.log("发生错误：" + error.message);
});

app.use(session({
    secret: 'secrect',
    resave: true,
    saveUninitialized: true,
    cookie:{
        maxAge: 3000*60 //cookie有效时间30min
    }
}));

app.get('/stuindex', function(req, res) {
    if(haveLogined(req.session.user)){
        res.redirect('/roomList');
    }else{
        res.render('stuindex',{'message':''});
    }
});

app.get('/teaindex', function(req, res) {
    if(haveLogined(req.session.user)){
        res.redirect('/roomList');
    }else{
        res.render('teaindex',{'message':''});
    }
});

app.get('/room', function(req, res) {
    if(haveLogined(req.session.user)){
        res.render('room',{username:req.session.user});
    }else{
        var type = req.session.type;
        if(type == "1"){
            res.redirect('/stuindex');
        }else if(type == "2"){
            res.redirect('/teaindex');
        }    
    }
});

app.get('/roomList', function (req, res) {
    if(haveLogined(req.session.user)){
        res.render('roomList',{roomList:SkyRTC.rtc.rooms,username:req.session.user});
    }else{
        var type = req.session.type;
        if(type == "1"){
            res.redirect('/stuindex');
        }else if(type == "2"){
            res.redirect('/teaindex');
        }    
    }
});


app.post('/enterRoom', function (req, res) {
    if(haveLogined(req.session.user)){
        var type = req.session.type;
        var selectSQL;
        if(type == '1'){
            selectSQL = "Select * from studenttable where studentnumber = '" + req.session.user + "'";
        }else if(type == '2'){
            selectSQL = "Select * from teachertable where teachernumber = '" + req.session.user + "'";      
        }
        connection.query(selectSQL,function(err,data){
            if(err){
                res.render('error',{'message':err})
            }else{
                if(data == null || data[0].approve == "0"){
                    res.writeHead(200,{'Content-Type':'text/html;charset=utf-8'});
                    res.write('<script>');
                    res.write('alert("暂时没有权限");window.location.href="roomList"');
                    res.write('</script>');
                }else if(data[0].approve == "1"){
                    roomList.enterRoomHttp(req.body.RoomNumber,req.session.user);
                    roomList.setRoomPassword(req.body.RoomNumber,req.body.Password);
                    res.redirect('/room#'+req.body.RoomNumber);
                }
            }
        });        
    }else{
        var type = req.session.type;
        if(type == "1"){
            res.redirect('/stuindex');
        }else if(type == "2"){
            res.redirect('/teaindex');
        }       
    }
});

app.post('/tryEnterRoom',function(req,res){

    if(haveLogined(req.session.user)){
        var roomNumber = req.body.RoomNumber;
        var password = req.body.Password;
        var mark = roomList.tryEnterRoom(roomNumber,password);
        if(mark == true){
            res.redirect('/room#'+req.body.RoomNumber);
        }else{
            res.writeHead(200,{
                'Content-Type':'text/html;charset=utf-8'
            });
            res.write('<script>');
            res.write('alert("输入密码错误");window.location.href="roomList"');
            res.write('</script>');
        }
    }else{
        var type = req.session.type;
        if(type == "1"){
            res.redirect('/stuindex');
        }else if(type == "2"){
            res.redirect('/teaindex');
        }       
    }
});

app.post('/login', function (req, res) {
	var studentnumber = req.body.studentnumber;
    var password = req.body.password;
    var rank = req.body.rank;
    var selectSQL;
    if(rank.toString() == "1"){
        selectSQL = "select * from studenttable where studentnumber = '"+studentnumber+"' and password = '"+password+"'";
    }else if(rank.toString() == "2"){
        selectSQL = "select * from teachertable where teachernumber = '"+studentnumber+"' and password = '"+password+"'";
    }else{
        alert("错误！");
    }
	connection.query(selectSQL,function (err,data) {
       
        if(err){
            res.render('error',{'message':err});
        }else{
            if(data==null){
                if(rank.toString() == "1"){
                    res.render('stuindex',{'message':'用户名或密码错误！'});
                }else{
                    res.render('teaindex',{'message':'用户名或密码错误！'});
                }                
            }else if(rank.toString() == "1" && req.body.studentnumber==data[0].studentnumber&&req.body.password==data[0].password){
                req.session.user = data[0].studentnumber;
                req.session.type = "1";
                res.redirect('/roomList');
            }else if(rank.toString() == "2" && req.body.studentnumber==data[0].teachernumber&&req.body.password==data[0].password){
                req.session.user = data[0].teachernumber;
                req.session.type = "2";
                res.redirect('/roomList');
            }else{                
                if(rank.toString() == "1"){
                    res.render('stuindex',{'message':'用户名或密码错误！'});
                }else{
                    res.render('teaindex',{'message':'用户名或密码错误！'});
                }    
            }
        }
    });
});

app.get('/logout', function (req, res) {
    var type = req.session.type;
   
    req.session.user = undefined;
    if(type == "1"){
        res.redirect('/stuindex');
    }else if(type == "2"){
        res.redirect('/teaindex');
    }   
});

app.post('/connectSuccess', function (req, res) {
    for(var room in SkyRTC.rtc.rooms){
        for(var i=0; i<SkyRTC.rtc.rooms[room].length;i++){
            if(SkyRTC.rtc.rooms[room][i].id == req.body.socketId){
                SkyRTC.rtc.rooms[room][i].ip = req.ip;
                SkyRTC.rtc.rooms[room][i].username = req.session.user;
            }
        }
    }
    res.write("success");
    res.end();
});

var isAdmin = function () {
    return true;
};

var haveLogined = function (user) {
    if(typeof(user) == "undefined"){
        return false;
    }else{
        return true;
    }
};