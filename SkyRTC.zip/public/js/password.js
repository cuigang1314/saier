
function getPassword(roomNuber){
    console.log(roomNuber);
    var password = prompt("请输入密码：","");
    if(password == undefined || password == ""){
        return false;
    }
    var form = document.createElement('form');
    form.action = "tryEnterRoom";
    form.method = "post";
    var hidenInput = document.createElement('input');
    hidenInput.type = 'hidden';
    hidenInput.name= "RoomNumber";   
    hidenInput.value= roomNuber;
    form.appendChild(hidenInput);  
    var input2 = document.createElement('input');
    input2.type='hidden';
    input2.name= "Password";   
    input2.value= password;
    form.appendChild(input2); 
    document.body.appendChild(form); 
    form.submit();
    return true;
}

function setPassword(){
    var password = prompt("请设置房间密码");
    if(password == undefined || password == ""){
        return false;
    }
    var ensure = prompt("请确认房间密码");
    if(ensure == undefined || ensure == ""){
        return false;
    }

    var roomId = document.getElementById("roomId").value;
    document.getElementById("roomId").value = "";
    if(roomId == undefined || roomId == ""){
        return false;
    }
    console.log("房间号"+roomId);
    if(password == ensure){
        var form = document.createElement('form');
        form.action = "enterRoom";
        form.method = "post";
        var hidenInput = document.createElement('input');
        hidenInput.type = 'hidden';
        hidenInput.name= "RoomNumber";   
        hidenInput.value= roomId;
        form.appendChild(hidenInput);  
        var input2 = document.createElement('input');
        input2.type='hidden';
        input2.name= "Password";   
        input2.value= password;
        form.appendChild(input2); 
        document.body.appendChild(form); 
        form.submit();
    }else{
        alert("两次输入的密码不一致");
    }
}