/**
 * Created by killer on 2016/10/27.
 */
var express = require('express');
var router = express.Router();
var roomList = [];
var RoomPassword = [];
var lastUser = null;


router.enterRoomHttp = function (roomNumber, username) {
    lastUser = username;
};

router.setRoomPassword = function(roomNumber,password){
    RoomPassword[roomNumber] = password;
};

router.tryEnterRoom = function (roomNumber,password){
    if(RoomPassword[roomNumber] == undefined){
        return false;
    }
    if(RoomPassword[roomNumber] != password){
        return false;
    }
    return true;
}

router.enterRoomSocket = function (roomNumber, socketId) {

    if(typeof(roomList[roomNumber]) == "undefined"){
        roomList[roomNumber] = [];   
    }
    console.log("这是加入的" + roomNumber);
    roomList[roomNumber].push({username:lastUser,socketId:socketId});
};

router.leaveRoom = function (socketId) {

};

module.exports = router;